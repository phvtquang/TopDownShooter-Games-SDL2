#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <string>
#include <vector>
#include <iostream>
#include <stdio.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>
#include <ctime>
#include <stdlib.h>
using namespace std;

const int SCREEN_WIDTH = 320*3;
const int SCREEN_HEIGHT = 320*3;