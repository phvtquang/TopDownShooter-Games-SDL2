#pragma once
#include "stdafx.h"
class gun
{
public:
	gun();
	void gunUPDATEPOSITION(int _x, int _y);
	SDL_Rect gunsourceRect;
	SDL_Rect gundesRect;
	SDL_Point centergunpoint;
	SDL_Point centergunpoint2;


private:

	

};

