#pragma once
#include "stdafx.h"
class texturehandle
{
public:
	SDL_Texture* LoadTexture(const std::string filepath , SDL_Renderer *render);

private:

};




